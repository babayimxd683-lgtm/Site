import { Github, Linkedin, Mail, ExternalLink } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-card border-t border-border">
      <div className="container py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <h3 className="text-2xl font-bold text-primary mb-2 neon-glow">turxanisback</h3>
            <p className="text-muted-foreground">
              Full Stack Developer & Discord Bot Expert. Modern web teknolojileri ve bot geliştirme konularında uzmanlaşmış.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold text-foreground mb-4">Hızlı Linkler</h4>
            <ul className="space-y-2">
              <li>
                <a href="#home" className="text-muted-foreground hover:text-primary transition-all duration-300">
                  Ana Sayfa
                </a>
              </li>
              <li>
                <a href="#about" className="text-muted-foreground hover:text-primary transition-all duration-300">
                  Hakkımda
                </a>
              </li>
              <li>
                <a href="#projects" className="text-muted-foreground hover:text-primary transition-all duration-300">
                  İşlerimiz
                </a>
              </li>
              <li>
                <a href="#services" className="text-muted-foreground hover:text-primary transition-all duration-300">
                  Hizmetlerimiz
                </a>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-bold text-foreground mb-4">Hizmetler</h4>
            <ul className="space-y-2">
              <li>
                <a href="#services" className="text-muted-foreground hover:text-primary transition-all duration-300">
                  Discord Bot Geliştirme
                </a>
              </li>
              <li>
                <a href="#services" className="text-muted-foreground hover:text-primary transition-all duration-300">
                  Web Geliştirme
                </a>
              </li>
              <li>
                <a href="#services" className="text-muted-foreground hover:text-primary transition-all duration-300">
                  Backend Geliştirme
                </a>
              </li>
            </ul>
          </div>

          {/* Social Links */}
          <div>
            <h4 className="text-lg font-bold text-foreground mb-4">Sosyal Ağlar</h4>
            <div className="flex gap-4">
              <a
                href="#"
                className="text-foreground hover:text-primary transition-all duration-300 hover-glow"
                title="GitHub"
              >
                <Github size={24} />
              </a>
              <a
                href="#"
                className="text-foreground hover:text-primary transition-all duration-300 hover-glow"
                title="LinkedIn"
              >
                <Linkedin size={24} />
              </a>
              <a
                href="#"
                className="text-foreground hover:text-accent transition-all duration-300 hover-glow-magenta"
                title="Email"
              >
                <Mail size={24} />
              </a>

            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-border my-8"></div>

        {/* Bottom */}
        <div className="flex flex-col md:flex-row justify-between items-center text-muted-foreground text-sm">
          <p>&copy; {currentYear} turxanisback. Tüm hakları saklıdır.</p>
          <p>Tasarım ve Geliştirme: turxanisback</p>
        </div>
      </div>
    </footer>
  );
}
