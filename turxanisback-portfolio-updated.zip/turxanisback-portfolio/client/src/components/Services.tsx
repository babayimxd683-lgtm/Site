import { motion } from 'framer-motion';
import { Code, Bot, Server } from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: Bot,
      title: 'Discord Bot Geliştirme',
      description: 'Özel ihtiyaçlarınıza göre Discord botları geliştiriyorum. Moderasyon, müzik, oyun ve daha fazlası.',
      features: ['Özel komutlar', 'Veritabanı entegrasyonu', '7/24 hosting', 'Sürekli destek'],
    },
    {
      icon: Code,
      title: 'Web Geliştirme',
      description: 'Modern ve responsive web siteleri geliştiriyorum. Kişisel sitelerden e-ticaret platformlarına kadar.',
      features: ['Responsive tasarım', 'SEO optimizasyonu', 'Hızlı yükleme', 'Mobil uyumlu'],
    },
    {
      icon: Server,
      title: 'Backend Geliştirme',
      description: 'Güvenli ve ölçeklenebilir backend sistemleri kuruyorum. API geliştirme ve veritabanı yönetimi.',
      features: ['RESTful API', 'Veritabanı tasarımı', 'Güvenlik', 'Performans'],
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section id="services" className="py-20 md:py-32 bg-background">
      <div className="container">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          variants={containerVariants}
        >
          <motion.h2
            className="text-4xl md:text-5xl font-bold mb-4 text-center neon-glow"
            variants={itemVariants}
          >
            Hizmetlerimiz
          </motion.h2>
          <motion.p
            className="text-center text-muted-foreground mb-16 max-w-2xl mx-auto"
            variants={itemVariants}
          >
            Sunduğum hizmetler ve uzmanlık alanlarım. Her hizmet, kalite ve müşteri memnuniyetine odaklanarak sunulur.
          </motion.p>

          <motion.div
            className="grid md:grid-cols-3 gap-8"
            variants={containerVariants}
          >
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={index}
                  className="glass glow-box rounded-lg p-8 hover-glow transition-all duration-300 hover:scale-105"
                  variants={itemVariants}
                  whileHover={{ y: -10 }}
                >
                  <div className="mb-4 inline-block p-3 bg-primary/20 rounded-lg">
                    <Icon className="text-primary" size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-primary mb-3 neon-glow">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-foreground">
                        <span className="w-2 h-2 bg-primary rounded-full"></span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              );
            })}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
