import { motion } from 'framer-motion';
import { ArrowRight, Github, Linkedin, Mail } from 'lucide-react';

export default function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: 'easeOut' as any }
    },
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16"
    >
      {/* Background Image */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663517035473/2VNzBrmPrsnaAYV54erssR/hero-bg-neon-YX2eucYhC8EG9HAqYFAN4S.webp)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background"></div>
      </div>

      {/* Content */}
      <motion.div
        className="container relative z-10 flex flex-col md:flex-row items-center justify-between gap-12"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Left Side - Profile Image */}
        <motion.div
          className="flex-1 flex justify-center md:justify-start"
          variants={itemVariants}
        >
          <div className="relative w-64 h-64 md:w-80 md:h-80">
            <div className="absolute inset-0 rounded-full neon-border animate-pulse"></div>
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663517035473/2VNzBrmPrsnaAYV54erssR/turxanisback-profile-pp-UGKLqv9DKjgQyhijVrsKbp.webp"
              alt="turxanisback"
              className="w-full h-full rounded-full object-cover"
            />
          </div>
        </motion.div>

        {/* Right Side - Text Content */}
        <motion.div className="flex-1 text-center md:text-left" variants={itemVariants}>
          <motion.h1
            className="text-5xl md:text-7xl font-bold mb-4 neon-glow"
            variants={itemVariants}
          >
            turxanisback
          </motion.h1>

          <motion.p
            className="text-2xl md:text-3xl text-primary mb-2 neon-glow-magenta"
            variants={itemVariants}
          >
            Full Stack Developer
          </motion.p>

          <motion.p
            className="text-xl md:text-2xl text-primary mb-6 neon-glow"
            variants={itemVariants}
          >
            Discord Bot Expert
          </motion.p>

          <motion.p
            className="text-lg text-muted-foreground mb-8 max-w-xl"
            variants={itemVariants}
          >
            3+ yıllık deneyimle modern web teknolojileri ve Discord bot geliştirme alanında uzmanlaşmış bir geliştiriciyim. Kullanıcı dostu ve performanslı çözümler üretmeyi seviyorum.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div className="flex flex-col sm:flex-row gap-4 mb-8" variants={itemVariants}>
            <a
              href="#projects"
              className="inline-flex items-center justify-center gap-2 px-8 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover-glow transition-all duration-300 hover:scale-105"
            >
              İşlerimi Gör <ArrowRight size={20} />
            </a>

          </motion.div>

          {/* Social Links */}
          <motion.div className="flex gap-6 justify-center md:justify-start" variants={itemVariants}>
            <a
              href="#"
              className="text-foreground hover:text-primary transition-all duration-300 hover-glow"
              title="GitHub"
            >
              <Github size={28} />
            </a>
            <a
              href="#"
              className="text-foreground hover:text-primary transition-all duration-300 hover-glow"
              title="LinkedIn"
            >
              <Linkedin size={28} />
            </a>
            <a
              href="#"
              className="text-foreground hover:text-accent transition-all duration-300 hover-glow-magenta"
              title="Email"
            >
              <Mail size={28} />
            </a>
          </motion.div>
        </motion.div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="text-primary text-sm">Aşağı Kaydır</div>
        <div className="text-primary text-2xl">↓</div>
      </motion.div>
    </section>
  );
}
