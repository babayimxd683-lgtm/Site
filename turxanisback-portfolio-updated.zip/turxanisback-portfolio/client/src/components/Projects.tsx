import { motion } from 'framer-motion';
import { ExternalLink, Github } from 'lucide-react';

export default function Projects() {
  const projects = [
    {
      title: 'Çok Fonksiyonlu Discord Botu',
      description: 'Moderasyon, müzik, oyun ve eğlence komutları içeren gelişmiş Discord botu. 10.000+ sunucuda aktif.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663517035473/2VNzBrmPrsnaAYV54erssR/project-card-1-Mv4PKf9e6NbcJeCF3YAoDF.webp',
      tags: ['Discord.js', 'Node.js', 'MongoDB'],
      links: { github: '#', demo: '#' },
    },
    {
      title: 'E-Ticaret Platformu',
      description: 'Modern tasarım ve güvenli ödeme sistemi ile tam özellikli e-ticaret sitesi. Stripe entegrasyonu.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663517035473/2VNzBrmPrsnaAYV54erssR/project-card-2-k6PxwTgMq4U6gxKoue3qGB.webp',
      tags: ['React', 'Express.js', 'Stripe'],
      links: { github: '#', demo: '#' },
    },
    {
      title: 'Backend API & Database',
      description: 'Veri analizi ve yönetim için responsive admin paneli tasarımı. RESTful API ve veritabanı yönetimi.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663517035473/2VNzBrmPrsnaAYV54erssR/project-card-3-a5wWQoEr2DghH9Wmhazj32.webp',
      tags: ['Node.js', 'PostgreSQL', 'API'],
      links: { github: '#', demo: '#' },
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section id="projects" className="py-20 md:py-32 bg-gradient-to-b from-card/50 to-background">
      <div className="container">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          variants={containerVariants}
        >
          <motion.h2
            className="text-4xl md:text-5xl font-bold mb-4 text-center neon-glow"
            variants={itemVariants}
          >
            İşlerimiz
          </motion.h2>
          <motion.p
            className="text-center text-muted-foreground mb-16 max-w-2xl mx-auto"
            variants={itemVariants}
          >
            Başarıyla tamamladığım projelerden bazıları. Her proje, müşteri ihtiyaçlarına ve en iyi uygulamalara göre özelleştirilmiştir.
          </motion.p>

          <motion.div
            className="grid md:grid-cols-3 gap-8"
            variants={containerVariants}
          >
            {projects.map((project, index) => (
              <motion.div
                key={index}
                className="glass glow-box rounded-lg overflow-hidden group hover-glow transition-all duration-300 hover:scale-105"
                variants={itemVariants}
                whileHover={{ y: -10 }}
              >
                <div className="relative h-48 overflow-hidden bg-card">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-all duration-300 duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-bold text-primary mb-2 neon-glow">
                    {project.title}
                  </h3>
                  <p className="text-muted-foreground mb-4 text-sm leading-relaxed">
                    {project.description}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-xs px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/30"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex gap-4">
                    <a
                      href={project.links.github}
                      className="flex items-center gap-2 text-foreground hover:text-primary transition-all duration-300 hover-glow"
                      title="GitHub"
                    >
                      <Github size={18} />
                      <span className="text-sm">Kod</span>
                    </a>
                    <a
                      href={project.links.demo}
                      className="flex items-center gap-2 text-foreground hover:text-primary transition-all duration-300 hover-glow"
                      title="Demo"
                    >
                      <ExternalLink size={18} />
                      <span className="text-sm">Demo</span>
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
