import { motion } from 'framer-motion';

export default function About() {
  const skills = [
    'JavaScript', 'TypeScript', 'React', 'Node.js',
    'Express.js', 'Discord.js', 'MongoDB', 'PostgreSQL',
    'Tailwind CSS', 'HTML/CSS', 'REST API', 'WebSocket'
  ];

  const stats = [
    { number: '50+', label: 'Tamamlanan Proje' },
    { number: '25+', label: 'Discord Botu' },
    { number: '100+', label: 'Mutlu Müşteri' },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section id="about" className="py-20 md:py-32 bg-gradient-to-b from-background to-card/50">
      <div className="container">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          variants={containerVariants}
        >
          <motion.h2
            className="text-4xl md:text-5xl font-bold mb-12 text-center neon-glow"
            variants={itemVariants}
          >
            Hakkımda
          </motion.h2>

          <div className="grid md:grid-cols-2 gap-12 mb-16">
            {/* Text Content */}
            <motion.div className="space-y-6" variants={itemVariants}>
              <h3 className="text-3xl font-bold text-primary">Merhaba, Ben turxanisback!</h3>
              <p className="text-lg text-foreground leading-relaxed">
                3+ yıllık deneyimle web geliştirme ve Discord bot programlama alanında çalışıyorum. Modern teknolojiler kullanarak kullanıcı dostu ve performanslı çözümler üretmeyi seviyorum.
              </p>
              <p className="text-lg text-foreground leading-relaxed">
                Başlangıçtan sonuna kadar proje yönetimi, kod kalitesi ve müşteri memnuniyetine odaklanıyorum. Her projede en iyi uygulamaları ve en son teknolojileri kullanmaya çalışıyorum.
              </p>
            </motion.div>

            {/* Stats */}
            <motion.div
              className="grid grid-cols-3 gap-6"
              variants={containerVariants}
            >
              {stats.map((stat) => (
                <motion.div
                  key={stat.label}
                  className="glass glow-box rounded-lg p-6 text-center"
                  variants={itemVariants}
                  whileHover={{ scale: 1.05 }}
                >
                  <div className="text-3xl md:text-4xl font-bold text-primary mb-2 neon-glow">
                    {stat.number}
                  </div>
                  <div className="text-sm md:text-base text-muted-foreground">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Skills */}
          <motion.div variants={itemVariants}>
            <h3 className="text-2xl font-bold mb-6 text-primary">Yeteneklerim</h3>
            <motion.div
              className="grid grid-cols-2 md:grid-cols-4 gap-4"
              variants={containerVariants}
            >
              {skills.map((skill) => (
                <motion.div
                  key={skill}
                  className="glass glow-box rounded-lg px-4 py-3 text-center text-foreground font-semibold hover-glow transition-all duration-300 hover:scale-105"
                  variants={itemVariants}
                  whileHover={{ scale: 1.05 }}
                >
                  {skill}
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
