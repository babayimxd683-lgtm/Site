# turxanisback Portföy Sitesi - Tasarım Konseptleri

## Referans Analizi
Gönderilen "RevanDev" portföy sitesi incelenmiş olup, aşağıdaki öğeler tespit edilmiştir:
- Temel yapı: Hero section, About, Projects, Services, Discord, Footer
- Teknoloji: HTML/CSS/JS vanilla
- Stil: Modern, karanlık mod odaklı, gradient kullanımı
- İçerik: Full Stack Developer & Discord Bot uzmanı

---

## Tasarım Konsepti: "Neon Minimalism"

**Seçilen Tasarım Felsefesi:** Neon Minimalism

### Design Movement
**Cyberpunk Minimalism** - Karanlık arka planlar üzerine parlak neon aksentler, minimalist layout, futuristik tipografi. 2020'lerin tech-forward estetikleri ile 90'ların cyberpunk estetiğinin birleşimi.

### Core Principles
1. **Kontrast Odaklı:** Derin siyah/koyu gri arka planlar üzerine parlak neon renkler (cyan, magenta, lime)
2. **Negatif Alan Kullanımı:** Bolca boşluk, minimal öğeler, maksimum etki
3. **Hiyerarşik Tipografi:** Kalın display fontlar başlıklar için, ince body fontlar içerik için
4. **Asimetrik Mizanpaj:** Diagonal kesimler, offset grid, dinamik layout

### Color Philosophy
- **Primer Palet:** Derin koyu gri (#0a0e27) arka plan, neon cyan (#00d9ff) ve magenta (#ff006e) aksentler
- **Duygusal İnten:** Teknoloji, güç, inovasyon, geleceğe bakış
- **Kontrastlı Metin:** Beyaz ve açık gri metinler koyu arka planlara karşı net görünürlük sağlar

### Layout Paradigm
- **Hero:** Diagonal cut, sol tarafta profil resmi, sağ tarafta metin ve CTA butonları
- **Bölümler:** Asimetrik grid, bazı kartlar tam genişlik, bazıları yan yana
- **Animasyonlar:** Scroll-triggered reveals, parallax efektleri, glow animations

### Signature Elements
1. **Neon Glow Efekti:** Başlıklar ve önemli öğelerde parlak glow
2. **Diagonal Dividers:** Bölümler arasında SVG diagonal kesimler
3. **Glassmorphism Kartları:** Yarı şeffaf arka planlar, blur efekti, neon border

### Interaction Philosophy
- **Hover Efektleri:** Butonlar ve kartlar hover'da glow artırır, renk değişir
- **Smooth Transitions:** Tüm animasyonlar 0.3-0.5s smooth easing
- **Scroll Animations:** Elementler scroll'a göre fade-in ve slide-up

### Animation
- **Entrance:** Elementler sayfaya girerken fade-in + slide-up (300ms)
- **Hover:** Butonlar ve kartlar hover'da scale(1.05) + glow artışı
- **Scroll:** Parallax arka plan, scroll-triggered reveal
- **Loading:** Pulsing neon glow animasyonu

### Typography System
- **Display Font:** "Space Grotesk" - Futuristik, kalın, başlıklar için
- **Body Font:** "Inter" - Modern, okunabilir, içerik için
- **Hierarchy:** H1 (48px), H2 (36px), H3 (24px), Body (16px), Small (14px)

---

## Teknik Detaylar

### Teknoloji Stack
- **Framework:** React 19 + Tailwind CSS 4
- **Animasyonlar:** Framer Motion
- **İkonlar:** Lucide React + Font Awesome
- **Bileşenler:** shadcn/ui

### Dosya Yapısı
```
client/src/
├── pages/
│   └── Home.tsx (Ana sayfa - tüm bölümleri içerir)
├── components/
│   ├── Navigation.tsx
│   ├── Hero.tsx
│   ├── About.tsx
│   ├── Projects.tsx
│   ├── Services.tsx
│   ├── Discord.tsx
│   └── Footer.tsx
├── App.tsx
└── index.css (Neon renk paleti)
```

### İçerik Yapısı
- **Kişi:** turxanisback
- **Başlık:** Full Stack Developer & Discord Bot Expert
- **Hakkımda:** 3+ yıl deneyim, modern teknolojiler, kullanıcı dostu çözümler
- **Projeler:** 3-4 örnek proje (Discord Bot, E-Commerce, Dashboard, vb.)
- **Hizmetler:** Discord Bot Geliştirme, Web Geliştirme, Backend Geliştirme
- **Discord:** Topluluk linki ve özellikler

---

## Tasarım Kararları

### Neden Neon Minimalism?
1. **Farklılaşma:** Tipik portföy sitelerinden ayırır
2. **Teknik Kimlik:** Developer/tech profesyoneli için uygun
3. **Modern Estetik:** 2024-2026 tasarım trendleri ile uyumlu
4. **Etkileyici:** Ziyaretçilerin hafızasında kalır

### Renkler Neden Bu Seçildi?
- **Cyan (#00d9ff):** Teknoloji, ilerleme, güven
- **Magenta (#ff006e):** Yaratıcılık, enerji, dikkat çekme
- **Koyu Gri (#0a0e27):** Profesyonellik, göz rahatlığı, modern

### Tipografi Neden Bu Seçildi?
- **Space Grotesk:** Futuristik, teknik, modern
- **Inter:** Okunabilir, profesyonel, evrensel
