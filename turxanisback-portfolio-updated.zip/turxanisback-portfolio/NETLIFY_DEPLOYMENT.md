# turxanisback Portföy Sitesi - Netlify Deployment Talimatları

## Hızlı Başlangıç

Bu portföy sitesini Netlify'a 7/24 yayına almak için aşağıdaki adımları takip edin.

### Adım 1: Netlify Hesabı Oluşturun
1. [Netlify](https://netlify.com) adresine gidin
2. GitHub, GitLab veya Bitbucket hesabınız ile giriş yapın (veya e-posta ile kayıt olun)

### Adım 2: Projeyi GitHub'a Yükleyin
1. GitHub'da yeni bir repository oluşturun (örn: `turxanisback-portfolio`)
2. Yerel makinenizde proje dizinine gidin
3. Aşağıdaki komutları çalıştırın:

```bash
git init
git add .
git commit -m "Initial commit: turxanisback portfolio"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/turxanisback-portfolio.git
git push -u origin main
```

### Adım 3: Netlify'da Deploy Edin
1. Netlify Dashboard'a gidin
2. "Add new site" → "Import an existing project" seçin
3. GitHub'ı seçin ve repository'yi seçin
4. Build ayarları:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist/public`
5. "Deploy site" butonuna tıklayın

### Adım 4: Custom Domain Bağlayın (İsteğe Bağlı)
1. Netlify Dashboard → Site settings → Domain management
2. "Add custom domain" seçin
3. Kendi domain adınızı girin (örn: turxanisback.com)
4. DNS ayarlarını yapılandırın

## Proje Yapısı

```
turxanisback-portfolio/
├── client/
│   ├── src/
│   │   ├── components/     # React bileşenleri
│   │   ├── pages/          # Sayfa bileşenleri
│   │   ├── index.css       # Global stiller (Neon Minimalism tema)
│   │   └── App.tsx         # Ana uygulama
│   ├── index.html
│   └── public/
├── server/                 # Backend (static deployment için kullanılmaz)
├── package.json
├── vite.config.ts
├── netlify.toml           # Netlify yapılandırması
└── README.md

```

## Teknoloji Stack

- **Frontend:** React 19 + Tailwind CSS 4
- **Animasyonlar:** Framer Motion
- **İkonlar:** Lucide React
- **Tasarım:** Neon Minimalism (Cyberpunk estetik)
- **Build Tool:** Vite
- **Hosting:** Netlify

## Tasarım Özellikleri

### Neon Minimalism Tema
- **Renkler:** Koyu arka plan (#0a0e27) + Neon Cyan (#00d9ff) + Neon Magenta (#ff006e)
- **Tipografi:** Space Grotesk (başlıklar) + Inter (gövde)
- **Efektler:** Glow efektleri, glassmorphism, smooth transitions
- **Animasyonlar:** Framer Motion ile scroll-triggered reveals

### Bölümler
1. **Navigation** - Sabit navbar, mobil menü desteği
2. **Hero** - Profil resmi, başlık, CTA butonları
3. **About** - Hakkımda, yetenekler, istatistikler
4. **Projects** - Proje kartları, teknoloji etiketleri
5. **Services** - Hizmet kartları, özellik listeleri
6. **Discord** - Discord sunucusu bilgileri ve davet linki
7. **Footer** - Sosyal linkler, hızlı linkler

## Kustomizasyon

### İçeriği Düzenlemek
1. `client/src/components/Hero.tsx` - Profil bilgileri ve resim
2. `client/src/components/About.tsx` - Hakkımda ve yetenekler
3. `client/src/components/Projects.tsx` - Proje örnekleri
4. `client/src/components/Services.tsx` - Hizmet açıklamaları
5. `client/src/components/Discord.tsx` - Discord linki

### Renkleri Değiştirmek
`client/src/index.css` dosyasında CSS değişkenlerini düzenleyin:
```css
--neon-cyan: #00d9ff;      /* Birincil renk */
--neon-magenta: #ff006e;   /* Aksan renk */
--background: #0a0e27;     /* Arka plan */
```

### Sosyal Linkler Eklemek
`client/src/components/Hero.tsx` ve `client/src/components/Footer.tsx` dosyalarında sosyal linkler bölümünü güncelleyin.

## Yerel Geliştirme

```bash
# Bağımlılıkları yükle
npm install

# Geliştirme sunucusunu başlat
npm run dev

# Build yap
npm run build

# Üretim sunucusunu çalıştır
npm run start

# TypeScript kontrolü
npm run check
```

## Sorun Giderme

### Build başarısız oluyorsa
1. Node.js sürümünü kontrol edin (22.13.0 önerilir)
2. `node_modules` ve `dist` dizinlerini silin
3. `npm install` komutunu çalıştırın
4. `npm run build` tekrar deneyin

### Netlify'da deploy başarısız oluyorsa
1. Netlify logs'ları kontrol edin
2. Build command'ın doğru olduğundan emin olun: `npm run build`
3. Publish directory'nin doğru olduğundan emin olun: `dist/public`

## İletişim ve Destek

- **Discord:** https://discord.gg/hQGxESEYKd
- **GitHub:** [Profiliniz]
- **Email:** [E-posta adresiniz]

---

**Hazır! Siteniz artık 7/24 Netlify'da yayında olacak.** 🚀
